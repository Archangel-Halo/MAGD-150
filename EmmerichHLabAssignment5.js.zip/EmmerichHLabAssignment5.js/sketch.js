let angleX = 0;
let angleY = 0;
let rotationSpeed = 0.1;

function setup() {
  createCanvas(512, 512, WEBGL);
  colorMode(RGB, 255, 255, 255);
  frameRate(5);
}

function draw() {
  background(220);
  
  rotateX(angleX);
  rotateY(angleY);
  
  box(100);
  
  let count = 0
  while (count < 5) {
    push();
    let x = random(-200, 200);
    let y = random(-200, 200);
    let z = random(-200, 200);
    translate(x, y, z);
    rotateY(frameCount * 0.01 + count);
    box(10);
    pop();
    count++;
  }
}

function keyPressed() {
  
    if (keyCode === UP_ARROW) {
      angleX -= rotationSpeed;
    } else if (keyCode === DOWN_ARROW) {
      angleX += rotationSpeed;
    } else if (keyCode === LEFT_ARROW) {
      angleY -= rotationSpeed;
    } else if (keyCode === RIGHT_ARROW) {
      angleY += rotationSpeed;
    }
    
}