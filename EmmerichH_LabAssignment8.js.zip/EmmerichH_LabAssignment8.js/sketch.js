//Setting Up Bubble Text
let yOffset = 0;
let baseY;
let amplitude = 10;
let speed = 0.03;

//Background Image
let backImg;

//Front Image
let frontImg;

function preload() {
  //Setting Background Image
  backImg = loadImage('/assets/ChristmasBackground.jpg');
  
  //Setting Front Image
  frontImg = loadImage('/assets/HappyFace.png')
  
}

function setup() {
  createCanvas(400, 400);
  textAlign(CENTER, CENTER);
  textSize(48);
  textFont('bubbleFont');
  noStroke();
  baseY = 70;
  baseY2 = 320;
  
}

function draw() {
  background(50);
  
  //Scaling for the Background Image
  push();
  scale(1.0, 2.0)
  image(backImg, 0, 0);
  pop();
  
  //Scaling for the Front Image
  push();
  scale(0.4, 0.4);
  image(frontImg, 180, 260);
  pop();
  
  //Both Sets of Text on Canvas
  push();
  let yMovement = sin(yOffset) * amplitude;
  fill(150 + 50 * sin(yOffset), 200, 100);
  text("YOU ARE", width / 2, baseY + yMovement);
  yOffset += speed;
  pop();
  
  push();
  fill(150 + 50 * sin(yOffset), 200, 100);
  text("UNINVITED!", width / 2, baseY2 + yMovement);
  yOffset += speed;
  pop();
}