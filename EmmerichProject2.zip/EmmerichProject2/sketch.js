let gui;
let sliderR, sliderG, sliderB;
let btn;
let targetColor = {r: 128, g: 128, b: 128};
let currentColor = {r: 128, g: 128, b: 128};
let history = [];

function setup(){
  let p5canvas = createCanvas(480, 320);
  gui = GUI.get(p5canvas);
  
  //RED SLIDER
  sliderR = gui.slider('sliderR', 20, 20, 200, 20)
  .limits(0, 255)
  .value(targetColor.r)
  .setAction(info => {
    targetColor.r = info.value;
  })
  
  //GREEN SLIDER
  sliderG = gui.slider('sliderG', 20, 60, 200, 20)
  .limits(0, 255)
  .value(targetColor.g)
  .setAction(info => {
    targetColor.g = info.value;
  })
  
  //BLUE SLIDER
  sliderB = gui.slider('sliderB', 20, 100, 200, 20)
  .limits(0, 255)
  .value(targetColor.b)
  .setAction(info => {
    targetColor.b = info.value;
  })
  
  //APPLY COLOR BUTTON
  btn = gui.button('btnColor', 250, 60, 120, 40)
  .text('Apply Color')
  .scheme('blue')
  .setAction(info => {
    history.push({ ...currentColor });
    currentColor = {...targetColor};
  })
  
  //RANDOM COLOR BUTTON
  randomBtn = gui.button("randomBtn", 20, 150, 200, 30)
  .text("Random Color")
  .scheme("green")
  .setAction(() => {
    sliderR.value(int(random(256)));
    sliderG.value(int(random(256)));
    sliderB.value(int(random(256)));
    
    targetColor = {
      r: sliderR.value(),
      g: sliderG.value(),
      b: sliderB.value()
    };
  });
  
  //UNDO BUTTON
  undoBtn = gui.button("undoBtn", 20, 190, 200, 30)
  .text("Undo")
  .scheme("red")
  .setAction(() => {
    if (history.length > 0) {
      currentColor = history.pop();
      
      sliderR.value(currentColor.r);
      sliderG.value(currentColor.g);
      sliderB.value(currentColor.b);
      
      targetColor = {
        r: currentColor.r,
        g: currentColor.g,
        b: currentColor.b
      };
    }
  });

}

function draw(){
  
  //COMPLEMENTARY COLOR
  let comp = {
    r: 255 - targetColor.r,
    g: 255 - targetColor.g,
    b: 255 - targetColor.b
  };
  
  fill(comp.r, comp.g, comp.b);
  rect(250, 20, 40, 20, 5);
  fill(0);
  textSize(10);
  text("Compliment", 310, 35);
  
  //BRIGHTNESS
  let brightness = (currentColor.r + currentColor.g + currentColor.b) / 3;
  let txtColor = brightness < 128 ? 255 : 0;
  
  fill(txtColor);
  textAlign(CENTER, CENTER);
  text("Applied", 310, 140);
  
  //BACKGROUND
  background(240);
  
  //DISPLAY BOXES
  noStroke();
  fill(targetColor.r, targetColor.g, targetColor.b);
  rect(250, 170, 120, 40, 10);
  fill(currentColor.r, currentColor.g, currentColor.b);
  rect(250, 120, 120, 40, 10);
  
  //HEX COLOR VALUE
  fill(0);
  textSize(12);
  text("HEX: #" + hex(targetColor.r, 2) + hex(targetColor.g, 2) + hex(targetColor.b, 2), 300, 230);
  
  gui.draw();
}
