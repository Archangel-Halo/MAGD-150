function setup() {
  createCanvas(512, 512);
  colorMode(RGB, 255, 255, 255, 1);
  
}

function draw() {
  background(220);
  
  let base = 3;
  let d = pow(base, 1);
  fill(200, 50, 100, 1);
  circle(10, 10, d);
  
  d = pow(base, 2);
  circle(20, 20, d);

  d = pow(base, 3);
  circle(40, 40, d);

  d = pow(base, 4);
  circle(80, 80, d);
  
  stroke(255, 0, 0, 1)
  line(mouseX, 0, mouseX, 512);
  stroke(0, 0, 255, 1)
  line(0, mouseY, width, mouseY);
  stroke(0, 0, 0, 1)
  line(pmouseX, pmouseY, mouseX, mouseY);
  
  textAlign(CENTER);
  textSize(16);
  fill(255, 40, 255, 1)
  text(`x: ${mouseX} y: ${mouseY}`, 460, 500);
  
  if (mouseIsPressed === true) {
    for (let i = 0; i < 1000000; i += 1) {
      random();
    }
  }
  let fps = frameRate();
  text(fps, 430, 480);
  
  let deg = 254;
  let rad = radians(deg);

  text(`${deg}˚ = ${round(rad, 3)} rad`, 440, 460);
  
}